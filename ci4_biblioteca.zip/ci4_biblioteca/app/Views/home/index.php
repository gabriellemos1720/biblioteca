<head>
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container text-light">
        <div>
            <h1>Biblioteca de Caucaia</h1>
            <br>
        </div>
        <div class="row p-4">
            <div class="col-7">
               <h4>
                Aqui você pode pegar livros emprestados
               </h4>
            </div>
        </div>
    </div>   
</body>