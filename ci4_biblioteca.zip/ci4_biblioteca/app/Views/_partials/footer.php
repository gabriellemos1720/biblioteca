    
    </body>
</html>
<script src="<?=base_url('assets/jquery/jquery.js')?>"></script>
<script src="<?=base_url('assets/bootstrap/js/bootstrap.bundle.js')?>"></script>